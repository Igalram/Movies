app.factory('favMoviesSrv', function() {

    var test= "do you see favMovieservice service???";
    console.log(test);
    
    var API_KEY = "ddce1bf04c2fe2731b0ba5290fd7c795";
    console.log(API_KEY);
    var movies = [];


//constructor
  function Movie(name, length, snippet, imdb, poster, id) {
    this.name = name;
    this.length = length;
    this.snippet = snippet;
    this.imdb = imdb;
    this.poster = poster;
    this.id = id;

  }

//hardcorded movie
  var movie = new Movie("The Rocky Horror Picture Show", 100, "chunky productions", "https://www.themoviedb.org/movie/36685-the-rocky-horror-picture-show?language=en-US", "https://image.tmdb.org/t/p/w600_and_h900_bestv2/v2NC7o8f7AZvQbOAwrfRbe5Z106.jpg");
  movies.push(movie);
  var movie = new Movie("The Rocky Horror Picture Show", 100, "chunky productions", "https://www.themoviedb.org/movie/36685-the-rocky-horror-picture-show?language=en-US", "https://image.tmdb.org/t/p/w600_and_h900_bestv2/v2NC7o8f7AZvQbOAwrfRbe5Z106.jpg");
  movies.push(movie);
  var movie = new Movie("The Rocky Horror Picture Show", 100, "chunky productions", "https://www.themoviedb.org/movie/36685-the-rocky-horror-picture-show?language=en-US", "https://image.tmdb.org/t/p/w600_and_h900_bestv2/v2NC7o8f7AZvQbOAwrfRbe5Z106.jpg");
  movies.push(movie);
  console.log(movies);

//show current favs in movies arr




//get movie
    getMovie = function (result) {
        var id="";
        var tempMovieObj;
        id=result.id;
        var getMovieUrl = "https://api.themoviedb.org/3/movie/" + id + "?api_key=" +
        API_KEY + "&language=en-US";

        $http.get(getMovieUrl).then(function (response) {
        tempMovieObj = response.data.results;
        console.log(tempMovieObj);

      }, 
      function (error) {
      console.error(error);
      })
    }
       
    return {wordRate : wordRate,
         API_KEY :  API_KEY,
        movies : movies   }

});