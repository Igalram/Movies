app.controller('moviesCtrl', function ($scope, $http, convertService, favMoviesSrv) {

  



  /*
    $http.get('actors.JSON').then(function(response) {
      response.data.forEach(function(plainObj) {
        var actor = new Actor (plainObj.name, plainObj.age, plainObj.imgURL, plainObj.url);
        $scope.actors.push(actor);
      })
  
  }, function(error) {
      console.error(error);
    });
  */

  
  $scope.query = "";
  $tempResults = [];
  $scope.wordRate = convertService.wordRate;
  $scope.API_KEY = favMoviesSrv.API_KEY;

  /*
      $scope.criteriaMatch = function (movie) {
  
          if (!$scope.query || movie.name.toLowerCase().includes($scope.query.toLowerCase())) { return true; }
          else { return false; }
  
      };
  
      $scope.sorts = [{label: 'Alphabetically', name: 'name'},{label: 'Birthday', name: 'age'}];
  
  
      $scope.movieSelected = null;
      $scope.setSelected = function (movieSelected) {
          $scope.movieSelected = movieSelected;
       };  */

  $scope.getResults = function (query) {
    if ($scope.query) {
      var searchUrl = "https://api.themoviedb.org/3/search/movie?api_key=" +
        $scope.API_KEY + "&language=en-US&query=" + encodeURIComponent($scope.query) +
        "&page=1&include_adult=false";

      $http.get(searchUrl).then(function (response) {
        $scope.tempResults = response.data.results;
        console.log($scope.tempResults);
        $scope.poster = "https://image.tmdb.org/t/p/w200" + $scope.tempResults.poster_path;

      }, 
      function (error) {
      console.error(error);
      })
    } else {
      $scope.tempResults = [];
    }
  }




});

