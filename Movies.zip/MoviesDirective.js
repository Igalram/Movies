app.directive("moviesDirective", function() {
    return {
      templateUrl: "moviesDirective.html",
      restrict: "E"
    }
  });